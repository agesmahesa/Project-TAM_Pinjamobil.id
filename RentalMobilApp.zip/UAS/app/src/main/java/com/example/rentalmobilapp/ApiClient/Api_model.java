package com.example.rentalmobilapp.ApiClient;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api_model {

    @POST("create.php")
    @FormUrlEncoded
    Call<Respone> createSewa(@Field("nama") String nama,
                             @Field("harga") int harga,
                             @Field("durasi") int waktu,
                             @Field("id_akun") int id_akun
    );

    @POST("create_akun.php")
    @FormUrlEncoded
    Call<Respone> createAkun(@Field("USERNAME") String username,
                             @Field("PASSWORD") String password,
                             @Field("PHONE") String phone
    );

    @POST("login.php")
    @FormUrlEncoded
    Call<LoginRespone> login(@Field("username") String username,
                             @Field("password") String password
    );
    @POST("read.php")
    @FormUrlEncoded
    Call< ArrayList<DataSewa> > getDataSewa(@Field("id_akun") int id);

}

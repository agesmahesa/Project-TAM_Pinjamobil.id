package com.example.rentalmobilapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.rentalmobilapp.ApiClient.TokenLogin;

import java.util.List;

public class FragmentContact extends Fragment {
    private ListView listView;
    private String mTitle[] = {"Facebook", "Whatsapp", "Instagram", "Youtube"};
    private String mDescription[] = {"Pinjamobil.id", "0895320046315", "@pinjamobil.id", "Pinjamobil.id"};
    private int images[] = {R.drawable.facebook, R.drawable.whatsapp, R.drawable.instagram, R.drawable.youtube};
    private Button logOut;
    public FragmentContact() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_contact, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        listView = view.findViewById(R.id.listView);
        logOut = view.findViewById(R.id.btn_logOut);
        MyAdapter myAdapter = new MyAdapter(requireActivity(), mTitle, mDescription, images);
        listView.setAdapter(myAdapter);
        logOut.setOnClickListener(view1 -> {
            TokenLogin tokenLogin = new TokenLogin(requireActivity());
            tokenLogin.removeSession();
            Intent logout = new Intent(requireActivity(), LoginActivity.class);
            logout.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(logout);
        });
    }

    private class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String[] rTitle;
        String[] rDescription;
        int[] rImgs;

        MyAdapter (Context c, String title[], String[] description, int[] imgs) {
            super(c, R.layout.row, R.id.textView1, title);
            this.context = c;
            this.rTitle = title;
            this.rDescription = description;
            this.rImgs = imgs;

        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)requireActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row, parent, false);
            ImageView images = row.findViewById(R.id.image);
            TextView myTitle = row.findViewById(R.id.textView1);
            TextView myDescription = row.findViewById(R.id.textView2);
            images.setImageResource(rImgs[position]);
            myTitle.setText(rTitle[position]);
            myDescription.setText(rDescription[position]);
            return row;
        }
    }
}
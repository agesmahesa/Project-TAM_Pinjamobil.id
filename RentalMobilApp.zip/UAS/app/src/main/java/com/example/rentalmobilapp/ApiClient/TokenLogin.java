package com.example.rentalmobilapp.ApiClient;

import android.content.Context;
import android.content.SharedPreferences;

public class TokenLogin {
    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;
    private final String IDKEY = "IDKEY";
    private final String USERNAMEKEY = "USERNAME";

    public TokenLogin(Context context) {
        this.sharedPreferences = context.getSharedPreferences("token",Context.MODE_PRIVATE);
        this.editor = sharedPreferences.edit();
    }
    public void saveSession(String username, int id){
        editor.putString(USERNAMEKEY, username).commit();
        editor.putInt(IDKEY,id).commit();
    }

    public String getSession(){
        return sharedPreferences.getString(USERNAMEKEY, "null");
    }
    public int getIdSession(){
        return sharedPreferences.getInt(IDKEY,0);
    }

    public void removeSession(){
        editor.putString(USERNAMEKEY,"null").commit();
        editor.putInt(IDKEY, 0).commit();
    }
}

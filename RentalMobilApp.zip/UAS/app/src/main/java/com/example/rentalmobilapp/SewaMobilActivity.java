package com.example.rentalmobilapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.rentalmobilapp.ApiClient.ApiKoneksi;
import com.example.rentalmobilapp.ApiClient.Respone;
import com.example.rentalmobilapp.ApiClient.TokenLogin;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SewaMobilActivity extends AppCompatActivity {
    int hargaSewa, lamaSewa, totalHargaSewa, jumlahUang;
    String sNama;
    Spinner ad_listmobil;
    TextView harga_mobil;
    EditText lama_sewa, uangbayar, nama_penyewa;
    private TokenLogin tokenLogin;

    String list_mobil[] = {"Toyota Avanza","Daihatsu Xenia","Mitsubisi Pajero","Toyota Fortuner"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sewa_mobil);
        nama_penyewa = findViewById(R.id.nama_penyewa);
        ad_listmobil = findViewById(R.id.ad_listmobil);
        harga_mobil = findViewById(R.id.harga_mobil);
        lama_sewa = findViewById(R.id.lama_sewa);
        uangbayar = findViewById(R.id.uangbayar);
        tokenLogin = new TokenLogin(this);
        ArrayAdapter ad_mbl = new ArrayAdapter(SewaMobilActivity.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,list_mobil);
        ad_listmobil.setAdapter(ad_mbl);
    }

    public void button_OK(View view) {
        lamaSewa = Integer.parseInt(lama_sewa.getText().toString());
        sNama = nama_penyewa.getText().toString();

        if(ad_listmobil.getSelectedItem().toString()=="Toyota Avanza"){
            hargaSewa = 300000;
            totalHargaSewa = lamaSewa * hargaSewa;
            harga_mobil.setText(Integer.toString(totalHargaSewa));
        } else if (ad_listmobil.getSelectedItem().toString() == "Daihatsu Xenia"){
            hargaSewa = 400000;
            totalHargaSewa = lamaSewa * hargaSewa;
            harga_mobil.setText(Integer.toString(totalHargaSewa));
        } else if (ad_listmobil.getSelectedItem().toString() == "Mitsubisi Pajero"){
            hargaSewa = 600000;
            totalHargaSewa = lamaSewa * hargaSewa;
            harga_mobil.setText(Integer.toString(totalHargaSewa));
        } else if (ad_listmobil.getSelectedItem().toString() == "Toyota Fortuner"){
            hargaSewa = 700000;
            totalHargaSewa = lamaSewa * hargaSewa;
            harga_mobil.setText(Integer.toString(totalHargaSewa));
        }
    }

    public void button_sewa2(View view) {
        jumlahUang = Integer.parseInt(uangbayar.getText().toString());
        if (jumlahUang < totalHargaSewa) {
            Toast.makeText(this, "Uang Anda Kurang", Toast.LENGTH_SHORT).show();
        }else{
            Intent intent = new Intent(SewaMobilActivity.this,StrukActivity.class);
            intent.putExtra("nama", sNama);
            intent.putExtra("mobil",ad_listmobil.getSelectedItem().toString());
            intent.putExtra("lama", lamaSewa);
            intent.putExtra("total", totalHargaSewa);
            intent.putExtra("uang", jumlahUang);
            intent.putExtra("kembalian", jumlahUang - totalHargaSewa);
            Call< Respone > call = ApiKoneksi.get().createSewa(ad_listmobil.getSelectedItem().toString(),
                    totalHargaSewa, lamaSewa,
                    tokenLogin.getIdSession());

            call.enqueue(new Callback< Respone >() {
                @Override
                public void onResponse(Call< Respone > call, Response< Respone > response) {
                    if (response.isSuccessful()){
                        if (response.body().getStatus().equals("success")){
                            startActivity(intent);
                        }
                    }
                }
                @Override
                public void onFailure(Call< Respone > call, Throwable t) {

                }
            });
        }
    }

    public void halaman_dashboard(View view) {
        Intent intent = new Intent(SewaMobilActivity.this,MainActivity.class);
        startActivity(intent);
    }
}

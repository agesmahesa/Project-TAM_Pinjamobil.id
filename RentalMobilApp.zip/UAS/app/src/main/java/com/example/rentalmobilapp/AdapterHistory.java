package com.example.rentalmobilapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rentalmobilapp.ApiClient.DataSewa;
import com.example.rentalmobilapp.databinding.ListItemBinding;

import java.util.ArrayList;

public class AdapterHistory extends RecyclerView.Adapter<AdapterHistory.HistoryHolder> {

    private ArrayList< DataSewa > sewa;
    private Context context;

    public AdapterHistory(ArrayList< DataSewa > sewa, Context context) {
        this.sewa = sewa;
        this.context = context;
    }


    @NonNull
    @Override
    public HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new HistoryHolder(ListItemBinding.inflate(LayoutInflater.from(parent.getContext())));
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryHolder holder, int position) {
        holder.itemBinding.namaMobil.setText(sewa.get(position).getNama());
        holder.itemBinding.durasi.setText(sewa.get(position).getDurasi() + " Hari");
        holder.itemBinding.harga.setText("Rp "+sewa.get(position).getHarga());
    }

    @Override
    public int getItemCount() {
        return sewa.size();
    }

    public static class HistoryHolder extends RecyclerView.ViewHolder {
        ListItemBinding itemBinding;
        public HistoryHolder(@NonNull ListItemBinding itemView) {
            super(itemView.getRoot());
            this.itemBinding = itemView;
        }
    }
}

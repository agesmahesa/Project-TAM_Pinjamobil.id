package com.example.rentalmobilapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.rentalmobilapp.ApiClient.ApiKoneksi;
import com.example.rentalmobilapp.ApiClient.LoginRespone;
import com.example.rentalmobilapp.ApiClient.TokenLogin;
import com.example.rentalmobilapp.databinding.ActivityLoginBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnRegister.setOnClickListener(view -> {
            Intent daftar = new Intent(this, RegisterActivity.class);
            startActivity(daftar);
        });

        binding.btnLogin.setOnClickListener(view -> {
            if (binding.etUsernameLogin.getText().toString().trim().isEmpty()){
                binding.etUsernameLogin.setError("Username harus di isi");
            }else if (binding.etPasswordLogin.getText().toString().trim().isEmpty()){
                binding.etPasswordLogin.setError("Password harus di isi");
            }else{
                loginUser();
            }
        });

    }

    private void loginUser() {
        Call< LoginRespone > call = ApiKoneksi.get().login(binding.etUsernameLogin.getText().toString().trim(),
                binding.etPasswordLogin.getText().toString().trim());
        call.enqueue(new Callback< LoginRespone >() {
            @Override
            public void onResponse(Call< LoginRespone > call, Response< LoginRespone > response) {
                if (response.isSuccessful()){
                    if (response.body().getStatus().equals("success")){
                        TokenLogin tokenLogin = new TokenLogin(LoginActivity.this);
                        tokenLogin.saveSession(response.body().getUsername(), Integer.parseInt(response.body().getId()));
                        Intent login = new Intent(LoginActivity.this, MainActivity.class);
                        login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(login);
                    }else if (response.body().getStatus().equals("password")){
                        Toast.makeText(LoginActivity.this, "Username & Password tidak cocok", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(LoginActivity.this, "Username tidak ditemukan", Toast.LENGTH_SHORT).show();
                    }

                }
            }
            @Override
            public void onFailure(Call< LoginRespone > call, Throwable t) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        TokenLogin token = new TokenLogin(LoginActivity.this);
        if (!token.getSession().equals("null")){
            Intent login = new Intent(LoginActivity.this, MainActivity.class);
            login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(login);
        }
    }
}
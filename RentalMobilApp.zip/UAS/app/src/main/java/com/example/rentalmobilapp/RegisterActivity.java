package com.example.rentalmobilapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.rentalmobilapp.ApiClient.ApiKoneksi;
import com.example.rentalmobilapp.ApiClient.Respone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    private EditText username, password, phone;
    private Button daftar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initView();
        daftar.setOnClickListener(view -> {
            if (username.getText().toString().trim().isEmpty()){
                username.setError("Username tidak boleh kosong");
            }else if (password.getText().toString().trim().isEmpty()){
                password.setError("Password tidak boleh kosong");
            }else if (phone.getText().toString().trim().isEmpty()){
                phone.setError("No.Handphone tidak boleh kosong");
            }else{
                buatAkun();
            }
        });
    }

    private void buatAkun() {
        Call< Respone > call = ApiKoneksi.get().createAkun(username.getText().toString().trim(),
                password.getText().toString().trim(),
                phone.getText().toString().trim());
        call.enqueue(new Callback< Respone >() {
            @Override
            public void onResponse(Call< Respone > call, Response< Respone > response) {
                if (response.isSuccessful()){
                    if (response.body().getStatus().equals("success")){
                        Toast.makeText(RegisterActivity.this, "Berhasil buat akun", Toast.LENGTH_SHORT).show();
                        Intent login = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(login);
                    }
                }
            }

            @Override
            public void onFailure(Call< Respone > call, Throwable t) {

            }
        });
    }

    private void initView() {
        username = findViewById(R.id.et_username_register);
        password = findViewById(R.id.et_password_register);
        phone = findViewById(R.id.et_password_phone);
        daftar = findViewById(R.id.btn_register_akun);
    }

}
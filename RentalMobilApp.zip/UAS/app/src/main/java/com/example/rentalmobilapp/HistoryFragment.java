package com.example.rentalmobilapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.rentalmobilapp.ApiClient.ApiKoneksi;
import com.example.rentalmobilapp.ApiClient.DataSewa;
import com.example.rentalmobilapp.ApiClient.TokenLogin;
import com.example.rentalmobilapp.databinding.FragmentHistoryBinding;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HistoryFragment extends Fragment {
    private FragmentHistoryBinding binding;
    private ArrayList< DataSewa > dataSewas;
    private  TokenLogin tokenLogin;
    public HistoryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentHistoryBinding.inflate(inflater, container, false);
        tokenLogin = new TokenLogin(requireActivity());
        loadData();
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }
    private void loadData() {
        Call<ArrayList<DataSewa>> call = ApiKoneksi.get().getDataSewa(tokenLogin.getIdSession());
        call.enqueue(new Callback< ArrayList< DataSewa > >() {
            @Override
            public void onResponse(Call< ArrayList< DataSewa > > call,
                                   Response< ArrayList< DataSewa > > response) {
                if (response.isSuccessful()){
                    AdapterHistory adapterHistory = new AdapterHistory(response.body(), requireActivity());
                    binding.listHistory.setLayoutManager(new LinearLayoutManager(requireActivity()));
                    binding.listHistory.setAdapter(adapterHistory);
                }
            }

            @Override
            public void onFailure(Call< ArrayList< DataSewa > > call, Throwable t) {

            }
        });
    }
}